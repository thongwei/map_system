package com.example.routeservice.comparator;


import com.example.routeservice.algorithm.NodeLabel;

import java.util.Comparator;

public class LComparator implements Comparator<NodeLabel> {
    @Override
    public int compare(NodeLabel o1, NodeLabel o2) {//长度小的优先级高
        return o1.getLength()>o2.getLength()? 1:(o1.getLength()<o2.getLength()? -1:0);
    }
}
