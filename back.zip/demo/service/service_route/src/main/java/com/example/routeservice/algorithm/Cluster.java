package com.example.routeservice.algorithm;


import com.example.routeservice.graph.Node;

import java.util.*;

public class Cluster {

    public HashMap<Integer,ArrayList<Node>> DBSCAN(HashSet<Node> D, double e, int minPts){
        HashMap<Integer,ArrayList<Node>> clusters = new HashMap<>();
        HashSet<Node> coreObject = new HashSet<>();
        HashSet<Node> unVisit = new HashSet<>();
        HashSet<Node> curUnVisit = new HashSet<>();
        Queue<Node> Q = new LinkedList<>();
        HashSet<Node> neis;
        for(Node n:D){
            neis = get_e_neighbors(D,n,e);
            if(neis.size()>=minPts){
                coreObject.add(n);
            }
        }
        int k=0;//初始化聚类簇数
        unVisit = (HashSet<Node>) D.clone();//初始化未访问样本集合
        while(coreObject.size()!=0){
            curUnVisit = (HashSet<Node>) unVisit.clone();
            ArrayList<Node> list = new ArrayList<>(coreObject);
            int randomIndex = new Random().nextInt(list.size());
            Node core = list.get(randomIndex);
            Q.add(core);
            unVisit.remove(core);
            while(Q.isEmpty()==false){
                Node n = Q.poll();
                neis = get_e_neighbors(D,n,e);
                if(neis.size()>=minPts){
                    HashSet<Node> delta = new HashSet<>();
                    for(Node nn:neis){
                        if(unVisit.contains(nn)){
                            delta.add(nn);
                        }
                    }
                    Q.addAll(delta);
                    unVisit.removeAll(delta);
                }
            }
            k+=1;
            curUnVisit.removeAll(unVisit);
            ArrayList<Node> cluster = new ArrayList<>();
            cluster.addAll(curUnVisit);
            clusters.put(k,cluster);
            coreObject.removeAll(curUnVisit);
        }
        return clusters;
    }

    public HashSet<Node> get_e_neighbors(HashSet<Node> D, Node x,double e){
        HashSet<Node> result = new HashSet<>();
        for(Node n:D){
            double dist = euclidean(n,x);
            if(dist<=e){
                result.add(n);
            }
        }
        return result;
    }

    public HashMap<Integer,ArrayList<Node>> hierarchical(HashSet<Node> D,double rate){
        int clusterId = 0,minId1,minId2;
        int cluNum;
        HashMap<Integer,ArrayList<Node>> clusters = new HashMap<>();
        HashMap<String,Integer> nearestClus;
        ArrayList<Node> clu1,clu2;
        for(Node node:D){
            ArrayList<Node> cluster = new ArrayList<>();
            cluster.add(node);
            clusters.put(clusterId,cluster);
            clusterId+=1;
        }
        cluNum = (int) (clusters.size()*rate);
        while(clusters.size()>cluNum){
            nearestClus = get_nearest_clus(clusters);
            minId1 = nearestClus.get("clu1");
            minId2 = nearestClus.get("clu2");
            clu1 = clusters.get(minId1);
            clu2 = clusters.get(minId2);
            clu1.addAll(clu2);
            clusters.remove(minId2);
        }
        return clusters;
    }

    public double euclidean(Node node1,Node node2){
        return Math.sqrt(Math.pow(node1.getX()-node2.getX(),2)+Math.pow(node1.getY()- node2.getY(),2));
    }

    public double get_distance(ArrayList<Node> clu1,ArrayList<Node> clu2){
        double totalDist=0,avgDist;
        int count=0;
        for(Node node1:clu1){
            for(Node node2:clu2){
                totalDist+=euclidean(node1,node2);
                count+=1;
            }
        }
        avgDist = totalDist/count;
        return avgDist;
    }

    public HashMap<String,Integer> get_nearest_clus(HashMap<Integer,ArrayList<Node>> clusters){
        double dist,minDist=99999;
        ArrayList<Node> clu1,clu2;
        int minId1=-1,minId2=-1;
        HashMap<String,Integer> result = new HashMap<>();
        for(Integer id1:clusters.keySet()){
            clu1 = clusters.get(id1);
            for(Integer id2:clusters.keySet()){
                clu2 = clusters.get(id2);
                if(id1!=id2){
                    dist = get_distance(clu1,clu2);
                    if(dist<minDist){
                        minDist = dist;
                        minId1 = id1;
                        minId2 = id2;
                    }
                }
            }
        }
        result.put("clu1",minId1);
        result.put("clu2",minId2);
        return result;
    }



}
