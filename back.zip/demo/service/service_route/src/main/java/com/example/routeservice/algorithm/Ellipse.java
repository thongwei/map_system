package com.example.routeservice.algorithm;

import com.example.routeservice.comparator.DistanceToComparator;
import com.example.routeservice.graph.Edge;
import com.example.routeservice.graph.Graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

public class Ellipse {
    private static final double EARTH_RADIUS=6371004;//单位m
    private static final double LONGITUDE_FACTOR=100000;//经度每相差1度，距离相差约100000米
    private static final double LANTITUDE_FACTOR=111320;//纬度每相差1度，距离相差约111320米

    //根据两点的经纬度求球面的直线距离
    public double getDistByLonAndLat(double lng1,double lat1,double lng2,double lat2){
        double radLng1,radLat1,radLng2,radLat2;
        radLng1 = Math.toRadians(lng1);
        radLat1 = Math.toRadians(lat1);
        radLng2 = Math.toRadians(lng2);
        radLat2 = Math.toRadians(lat2);
        double a = radLat1-radLat2;//纬度之差
        double b = radLng1-radLng2;//经度之差
        //半正矢公式
        double s = 2*EARTH_RADIUS*Math.asin(Math.sqrt(Math.pow(Math.sin(a/2),2)+
                Math.cos(lat1)*Math.cos(lat2)*Math.pow(Math.sin(b/2),2)));
        return s;//单位m
    }

    //计算点到直线的距离
    public double getDistFromNodeToLine(double x,double y,double k,double b){
        return Math.abs(k*x-y+b)/Math.sqrt(k*k+1);
    }

    //判断一点是否在椭圆内
    public boolean isNodeInEllipse(double x,double y,double a,double b){
        if(((x*x)/(a*a)+(y*y)/(b*b))<=1){
            return true;
        }else{
            return false;
        }
    }

    //判断一点是否在椭圆内
    public boolean isNodeInEllipse1(double a,double x,double y,double c1_x,double c1_y,double c2_x,double c2_y){
        double dist1,dist2;
        dist1 = getDistByLonAndLat(x,y,c1_x,c1_y);
        dist2 = getDistByLonAndLat(x,y,c2_x,c2_y);
        if((dist1+dist2)<=(2*a)){
            return true;
        }else{
            return false;
        }
    }

    //计算椭圆搜索区域 ICDE
    public Graph createEllipseSubgraphByab(Graph G, int start, int end, ArrayList<Integer> path, String nodeFileName){
        Graph ellipseGraph;
        HashMap<Integer, HashMap<String,Double>> node_dict = G.getNodeDict(nodeFileName);
        double start_x,start_y,end_x,end_y,o_x,o_y;
        double a,b;
        HashSet<Integer> subNodeSet = new HashSet<>();//子图节点集
        start_x = (double)node_dict.get(start).get("x");
        start_y = (double)node_dict.get(start).get("y");
        end_x = (double)node_dict.get(end).get("x");
        end_y = (double)node_dict.get(end).get("y");
        o_x = (start_x+end_x)/2;
        o_y = (start_y+end_y)/2;
        //欧式距离求a
        a = 1.2*Math.sqrt(Math.pow(start_x-end_x,2)+Math.pow(start_y-end_y,2))/2;
        double k1 = (start_y-end_y)/(start_x-end_x);//斜率
        double b1 = start_y-k1*start_x;
        double d,d_max=-1,x,y,temp_x,temp_y;
        for(Integer node:path){
            x = (double)node_dict.get(node).get("x");
            y = (double)node_dict.get(node).get("y");
            d = getDistFromNodeToLine(x,y,k1,b1);
            if(d>d_max){
                d_max = d;
            }
        }
        //求b
        b=d_max;
        //对最短路径中的结点进行排序
        ArrayList<DistanceTo> nodes = new ArrayList<>();
        for(Integer node:path){
            x = (double)node_dict.get(node).get("x");
            y = (double)node_dict.get(node).get("y");
            double dist = getDistFromNodeToLine(x,y,k1,b1);
            DistanceTo distanceTo = new DistanceTo(node,dist);
            nodes.add(distanceTo);
        }
        DistanceToComparator comparator = new DistanceToComparator();
        Collections.sort(nodes,comparator);
        ArrayList<Integer> new_path = new ArrayList<>();
        for(DistanceTo node:nodes){
            new_path.add(node.getNode());
        }
        //精炼b
        for(Integer node:new_path){
            x = (double)node_dict.get(node).get("x");
            y = (double)node_dict.get(node).get("y");
            temp_x = x-o_x;
            temp_y = y-o_y;
            if(isNodeInEllipse(temp_x,temp_y,a,b)==false){
                b = Math.sqrt((temp_y*temp_y)/(1-(temp_x*temp_x)/(a*a)));
            }
        }
        if(b<a){
            a = Math.sqrt(a*a+b*b);
        }
        //求在椭圆内的子结点集
        for(Integer node:G.getAdjList().keySet()){
            x = (double)node_dict.get(node).get("x");
            y = (double)node_dict.get(node).get("y");
            temp_x = x-o_x;
            temp_y = y-o_y;
            if(isNodeInEllipse(temp_x,temp_y,a,b)){
                subNodeSet.add(node);
            }
        }
        //System.out.println("子节点集大小:"+subNodeSet.size());
        ellipseGraph = getSubGraph(G,subNodeSet);
        return ellipseGraph;
    }

    //计算椭圆搜索区域 My
    public Graph createEllipseSubgraphByabc(Graph G, int start, int end, double e, String nodeFileName){
        double a,b,c;
        double x,y,temp_x,temp_y;
        Graph ellipseGraph;
        HashSet<Integer> subNodeSet = new HashSet<>();//子图节点集
        double start_x,start_y,end_x,end_y,o_x,o_y;
        HashMap<Integer, HashMap<String,Double>> node_dict = G.getNodeDict(nodeFileName);
        start_x = (double)node_dict.get(start).get("x");
        start_y = (double)node_dict.get(start).get("y");
        end_x = (double)node_dict.get(end).get("x");
        end_y = (double)node_dict.get(end).get("y");
        o_x = (start_x+end_x)/2;
        o_y = (start_y+end_y)/2;
        a = e/2;
        c = getDistByLonAndLat(start_x,start_y,end_x,end_y)/2;
        b = Math.sqrt(a*a-c*c);
        //求在椭圆内的子结点集
        for(Integer node:G.getAdjList().keySet()){
            x = (double)node_dict.get(node).get("x");
            y = (double)node_dict.get(node).get("y");
            //temp_x = (x-o_x)*LONGITUDE_FACTOR;
            //temp_y = (y-o_y)*LANTITUDE_FACTOR;
            //if(isNodeInEllipse(temp_x,temp_y,a,b)){
                //subNodeSet.add(node);
            //}
            if(isNodeInEllipse1(a,x,y,start_x,start_y,end_x,end_y)){
                subNodeSet.add(node);
            }
        }
        //System.out.println("子节点集大小:"+subNodeSet.size());
        ellipseGraph = getSubGraph(G,subNodeSet);
        return ellipseGraph;
    }


    //根据子节点集构建子图
    public Graph getSubGraph(Graph G,HashSet<Integer> nodeSet){
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();
        Graph subGraph = new Graph();
        HashMap<Integer,Integer> exist = new HashMap<>();
        for(Integer node:adjList.keySet()){
            exist.put(node,0);
        }
        for(Integer node:nodeSet){
            exist.put(node,1);
        }
        for(Integer node:nodeSet){
            subGraph.getAdjList().put(node,new ArrayList<Edge>());
            for(Edge edge:adjList.get(node)){
                if(exist.get(edge.getHead())==1){
                    subGraph.getAdjList().get(node).add(edge);
                }
            }
        }
        return subGraph;
    }

}
