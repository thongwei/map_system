package com.example.routeservice.commonutils;

public class RowElement {
    private String[] cols;

    public RowElement(String[] cols) {
        this.cols = cols;
    }

    public String getCol(int index) {
        return cols[index];
    }
}
