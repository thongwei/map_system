package com.example.routeservice.comparator;

import com.example.routeservice.algorithm.NodeLabel;

import java.util.Comparator;

public class SComparator implements Comparator<NodeLabel> {
    @Override
    public int compare(NodeLabel o1, NodeLabel o2) {// 分数小的优先级高
        return o1.getScore()>o2.getScore()? 1:(o1.getScore()<o2.getScore()? -1:0);
    }
}
