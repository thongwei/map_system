package com.example.routeservice.algorithm;


import com.example.routeservice.commonutils.CsvUtil;
import com.example.routeservice.commonutils.RowElement;
import com.example.routeservice.graph.Edge;
import com.example.routeservice.graph.Graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PoiRecommendate {

    public ArrayList<Integer> getPath(Graph G, ArrayList<Integer> poiList, double e, String poiEdgeFileName){
        int tail,head,start,end,anotherNode;
        ArrayList<Integer> result,subPath1,subPath2;
        double lenght1,length2,length;
        Edge edge;
        result = new ArrayList<>();
        HashMap<Integer,Double> dists = new HashMap<>();
        HashMap<Integer,HashMap<String,Integer>> poi_edge_dict = getPoiEdgeDict(poiEdgeFileName);
        start = poi_edge_dict.get(poiList.get(0)).get("tail");//默认以第一条边的尾结点为起点
        System.out.println("起点："+start);
        anotherNode = start;
        for(int i=1;i<poiList.size();i+=1){
            System.out.println("第"+i+"轮");
            tail = poi_edge_dict.get(poiList.get(i)).get("tail");
            head = poi_edge_dict.get(poiList.get(i)).get("head");
            edge = getEdgeByNode(G,tail,head);
            if(edge.getVisit()==1){
                continue;
            }
            subPath1 = AlgorithmUtil.singleDijkstra(G,start,tail);
            subPath2 = AlgorithmUtil.singleDijkstra(G,start,head);
            if(subPath1.size()==0 && subPath2.size()==0){
                continue;
            }
            else if(subPath1.size()==0){//path1不可达，走path2
                end = head;
                anotherNode = tail;
                result.addAll(subPath2);
            }
            else if(subPath2.size()==0){//path2不可达，走path1
                end = tail;
                anotherNode = head;
                result.addAll(subPath1);
            }
            else{
                lenght1 = AlgorithmUtil.getPathInfo(G,subPath1,"length");
                length2 = AlgorithmUtil.getPathInfo(G,subPath2,"length");
                if(lenght1<=length2){
                    end = tail;
                    anotherNode = head;
                    result.addAll(subPath1);
                }
                else{
                    end = head;
                    anotherNode = tail;
                    result.addAll(subPath2);
                }
            }
            System.out.println(AlgorithmUtil.getPathInfo(G,result,"length"));
            start = anotherNode;
            length = AlgorithmUtil.getPathInfo(G,result,"length");
            if(length>e){
                return result;
            }
            makeVisit(G,result);
        }
        result.add(anotherNode);
        visitRecover(G);
        return result;
    }


    public HashMap<Integer, HashMap<String,Integer>> getPoiEdgeDict(String poiEdgeFileName){
        HashMap<Integer,HashMap<String,Integer>> poi_edge_dict = new HashMap<>();
        HashMap<String,Integer> edge_nodes = null;
        List<RowElement> rows = null;
        rows = CsvUtil.readCSV(poiEdgeFileName);
        int id=0;
        int tail=-1,head=-1;
        for(RowElement row:rows){
            id = Integer.parseInt(row.getCol(0));
            tail = Integer.parseInt(row.getCol(1));
            head = Integer.parseInt(row.getCol(2));
            edge_nodes = new HashMap<>();
            edge_nodes.put("tail",tail);
            edge_nodes.put("head",head);
            poi_edge_dict.put(id,edge_nodes);
        }
        return poi_edge_dict;
    }

    public Edge getEdgeByNode(Graph G, int tail, int head){
        Edge result = null;
        for(Edge edge:G.getAdjList().get(tail)){
            if(edge.getHead()==head){
                result = edge;
            }
        }
        return result;
    }

    public void visitRecover(Graph G){
        for(Integer node:G.getAdjList().keySet()){
            for(Edge edge:G.getAdjList().get(node)){
                edge.setVisit(-1);//恢复访问
            }
        }
    }

    public void makeVisit(Graph G,ArrayList<Integer> path){
        int tail,head;
        Edge edge1,edge2;
        for(int i=0;i<path.size()-1;i++){
            tail = path.get(i);
            head = path.get(i+1);
            edge1 = getEdgeByNode(G,tail,head);
            edge2 = getEdgeByNode(G,head,tail);
            edge1.setVisit(1);
            edge2.setVisit(1);
        }
    }


}
