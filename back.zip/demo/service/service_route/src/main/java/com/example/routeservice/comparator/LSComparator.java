package com.example.routeservice.comparator;


import com.example.routeservice.algorithm.NodeLabel;

import java.util.Comparator;

public class LSComparator implements Comparator<NodeLabel> {
    @Override
    public int compare(NodeLabel o1, NodeLabel o2) {//长度大的优先级高，若长度相等，则分数大的优先级高
        int order=0;
        double gap = o2.getLength() - o1.getLength();
        if(gap!=0){
            order = (gap>0)?2:-1;
        }
        else{
            gap = o2.getScore() - o1.getScore();
            if(gap!=0){
                order = (gap>0)?1:-2;
            }
        }
        return order;
    }
}
