package com.example.routeservice.algorithm;

public class NodeLabel {
    private int pathId;
    private int node;
    private double length;
    private double score;
    private double density;


    public NodeLabel(){

    }

    public NodeLabel(int pathId, int node) {
        this.pathId = pathId;
        this.node = node;
        this.length = -1;
        this.score = -1;
    }

    public NodeLabel(int node, double length) {
        this.pathId = -1;
        this.node = node;
        this.length = length;
        this.score = -1;
    }

    public NodeLabel(int pathId, int node, double length) {
        this.pathId = pathId;
        this.node = node;
        this.length = length;
        this.score = -1;
    }


    public NodeLabel(int pathId, int node, double length, double score) {
        this.pathId = pathId;
        this.node = node;
        this.length = length;
        this.score = score;
    }

    public NodeLabel(int pathId, int node, double length, double score, double density) {
        this.pathId = pathId;
        this.node = node;
        this.length = length;
        this.score = score;
        this.density = density;
    }

    public int getPathId() {
        return pathId;
    }

    public void setPathId(int pathId) {
        this.pathId = pathId;
    }

    public int getNode() {
        return node;
    }

    public void setNode(int node) {
        this.node = node;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public double getDensity() {
        return density;
    }

    public void setDensity(double density) {
        this.density = density;
    }
}
