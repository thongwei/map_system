package com.example.routeservice.algorithm;

public class DistanceTo {
    private int node;
    private double distance;

    public DistanceTo(int node, double distance) {
        this.node = node;
        this.distance = distance;
    }

    public int getNode() {
        return node;
    }

    public void setNode(int node) {
        this.node = node;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }
}
