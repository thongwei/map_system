package com.example.routeservice.service.impl;

import com.example.routeservice.algorithm.AlgorithmUtil;
import com.example.routeservice.algorithm.DestinationQuery;
import com.example.routeservice.algorithm.RangeQuery;
import com.example.routeservice.commonutils.CsvUtil;
import com.example.routeservice.commonutils.RowElement;
import com.example.routeservice.graph.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class RouteServiceImpl {
    public static final String NODE_FILE_NAME = "./service/service_route/file/suzhou/nodes_suzhou.csv";
    public static final String EDGE_FILE_NAME = "./service/service_route/file/suzhou/edges_suzhou.csv";
    public static final String POI_FILE_NAME = "./service/service_route/file/suzhou/poi_suzhou.csv";
    public static final String POI_EDGE_FILE_NAME = "./service/service_route/file/suzhou/poi_edge_suzhou.csv";
    public static final String KEYWORD_FILE_NAME = "./service/service_route/file/code_name.csv";

    //查询最大分数路径
    public Path queryScoreRoute(double x1, double y1, String code, double e){
        Graph G = new Graph();
        G.initGraph(NODE_FILE_NAME,EDGE_FILE_NAME);
        G.addPoi(POI_EDGE_FILE_NAME);
        HashMap<Integer, HashMap<String,Double>> node_dict = G.getNodeDict(NODE_FILE_NAME);
        HashMap<Integer, HashMap<String,Object>> poi_dict = G.getPoiDict(POI_FILE_NAME);

        int start = AlgorithmUtil.getNearestNode(G,x1,y1,node_dict);
        RangeQuery query = new RangeQuery();
        ArrayList<Integer> path = query.prune3(G, start, code, e, 50, poi_dict);
        ArrayList<Node> nodes = getResultPath(path, node_dict);
        ArrayList<POI> pois = getPOIs(G,path,code,poi_dict);
        double length = AlgorithmUtil.getPathInfo(G,path,"length");
        Path resultPath = new Path();
        resultPath.setNodes(nodes);
        resultPath.setPois(pois);
        resultPath.setLength(Math.round(length));
        return resultPath;
    }

    //查询最大分数路径_baseline
    public Path queryScoreRoute_baseline(double x1, double y1, String code, double e){
        Graph G = new Graph();
        G.initGraph(NODE_FILE_NAME,EDGE_FILE_NAME);
        G.addPoi(POI_EDGE_FILE_NAME);
        HashMap<Integer, HashMap<String,Double>> node_dict = G.getNodeDict(NODE_FILE_NAME);
        HashMap<Integer, HashMap<String,Object>> poi_dict = G.getPoiDict(POI_FILE_NAME);

        int start = AlgorithmUtil.getNearestNode(G,x1,y1,node_dict);
        RangeQuery query = new RangeQuery();
        ArrayList<Integer> path = query.simpleGreedy(G, start, code, e, poi_dict);
        ArrayList<Node> nodes = getResultPath(path, node_dict);
        ArrayList<POI> pois = getPOIs(G,path,code,poi_dict);
        double length = AlgorithmUtil.getPathInfo(G,path,"length");
        Path resultPath = new Path();
        resultPath.setNodes(nodes);
        resultPath.setPois(pois);
        resultPath.setLength(Math.round(length));
        return resultPath;
    }

    //查询最大密度路径
    public Path queryDensityRoute_Astar(double x1, double y1, double x2, double y2, String code, double e){
        Graph G = new Graph();
        G.initGraph(NODE_FILE_NAME,EDGE_FILE_NAME);
        G.addPoi(POI_EDGE_FILE_NAME);
        HashMap<Integer, HashMap<String,Double>> node_dict = G.getNodeDict(NODE_FILE_NAME);
        HashMap<Integer, HashMap<String,Object>> poi_dict = G.getPoiDict(POI_FILE_NAME);

        int start = AlgorithmUtil.getNearestNode(G,x1,y1,node_dict);
        int end = AlgorithmUtil.getNearestNode(G,x2,y2,node_dict);
        DestinationQuery query = new DestinationQuery();
        ArrayList<Integer> path = query.A_star(G, start, end, code, e, poi_dict);
        ArrayList<Node> nodes = getResultPath(path, node_dict);
        ArrayList<POI> pois = getPOIs(G,path,code,poi_dict);
        double length = AlgorithmUtil.getPathInfo(G,path,"length");
        double score = AlgorithmUtil.getPathInfo(G, path, "score");
        Path resultPath = new Path();
        resultPath.setNodes(nodes);
        resultPath.setPois(pois);
        resultPath.setLength(Math.round(length));
        resultPath.setDensity(Double.parseDouble(String.format("%.4f",score/length)));
        return resultPath;
    }

    //查询最大密度路径
    public Path queryDensityRoute(double x1, double y1, double x2, double y2, String code, double e){
        Graph G = new Graph();
        G.initGraph(NODE_FILE_NAME,EDGE_FILE_NAME);
        G.addPoi(POI_EDGE_FILE_NAME);
        HashMap<Integer, HashMap<String,Double>> node_dict = G.getNodeDict(NODE_FILE_NAME);
        HashMap<Integer, HashMap<String,Object>> poi_dict = G.getPoiDict(POI_FILE_NAME);

        int start = AlgorithmUtil.getNearestNode(G,x1,y1,node_dict);
        int end = AlgorithmUtil.getNearestNode(G,x2,y2,node_dict);
        DestinationQuery query = new DestinationQuery();
        ArrayList<Integer> path = query.kNE(G, start, end, code, e, 50, poi_dict);
        ArrayList<Node> nodes = getResultPath(path, node_dict);
        ArrayList<POI> pois = getPOIs(G,path,code,poi_dict);
        double length = AlgorithmUtil.getPathInfo(G,path,"length");
        double score = AlgorithmUtil.getPathInfo(G, path, "score");
        Path resultPath = new Path();
        resultPath.setNodes(nodes);
        resultPath.setPois(pois);
        resultPath.setLength(Math.round(length));
        resultPath.setDensity(Double.parseDouble(String.format("%.4f",score/length)));
        return resultPath;
    }

    //查询最大密度路径_baseline
    public Path queryDensityRoute_baseline(double x1, double y1, double x2, double y2, String code, double e){
        Graph G = new Graph();
        G.initGraph(NODE_FILE_NAME,EDGE_FILE_NAME);
        G.addPoi(POI_EDGE_FILE_NAME);
        HashMap<Integer, HashMap<String,Double>> node_dict = G.getNodeDict(NODE_FILE_NAME);
        HashMap<Integer, HashMap<String,Object>> poi_dict = G.getPoiDict(POI_FILE_NAME);

        int start = AlgorithmUtil.getNearestNode(G,x1,y1,node_dict);
        int end = AlgorithmUtil.getNearestNode(G,x2,y2,node_dict);
        DestinationQuery query = new DestinationQuery();
        ArrayList<Integer> path = query.labelSetting(G, start, end, code, e, poi_dict);
        ArrayList<Node> nodes = getResultPath(path, node_dict);
        ArrayList<POI> pois = getPOIs(G,path,code,poi_dict);
        double length = AlgorithmUtil.getPathInfo(G,path,"length");
        double score = AlgorithmUtil.getPathInfo(G, path, "score");
        Path resultPath = new Path();
        resultPath.setNodes(nodes);
        resultPath.setPois(pois);
        resultPath.setLength(Math.round(length));
        resultPath.setDensity(Double.parseDouble(String.format("%.4f",score/length)));
        return resultPath;
    }

    //返回路径上结点的经纬度集合
    public ArrayList<Node> getResultPath(ArrayList<Integer> path,HashMap<Integer, HashMap<String,Double>> node_dict){
        ArrayList<Node> resultPath = new ArrayList<>();
        HashMap<String,Double> node_attr;
        for(int nodeId:path){
            node_attr = node_dict.get(nodeId);
            double x = node_attr.get("x");
            double y = node_attr.get("y");
            Node node = new Node(nodeId,x,y);
            resultPath.add(node);
        }
        return resultPath;
    }

    //获取关键字信息
    public ArrayList<Keyword> getKeywords(){
        String code,name;
        ArrayList<Keyword> result = new ArrayList<>();
        List<RowElement> rowElements = CsvUtil.readCSV(KEYWORD_FILE_NAME);
        for(RowElement rowElement:rowElements){
            code = rowElement.getCol(0);
            name = rowElement.getCol(1);
            Keyword keyword = new Keyword(code,name);
            result.add(keyword);
        }
        return result;
    }

    //获取路径上的POI
    public ArrayList<POI> getPOIs(Graph G, ArrayList<Integer> path, String code, HashMap<Integer,HashMap<String,Object>> poi_dict){
        ArrayList<POI> result = new ArrayList<>();
        HashMap<String,Object> poi_attr;
        ArrayList<Integer> poIs = AlgorithmUtil.getPOIs(G, path, code, poi_dict);
        for(int poiId:poIs){
            poi_attr = poi_dict.get(poiId);
            double x = (double) poi_attr.get("lng");
            double y = (double) poi_attr.get("lat");
            double rating = (double) poi_attr.get("rating");
            String name = (String)poi_attr.get("name");
            POI poi = new POI(x,y,rating,name);
            result.add(poi);
        }
        return result;
    }
}
