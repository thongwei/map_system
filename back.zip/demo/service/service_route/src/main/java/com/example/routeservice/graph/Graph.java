package com.example.routeservice.graph;


import com.example.routeservice.commonutils.CsvUtil;
import com.example.routeservice.commonutils.RowElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Graph {
    private HashMap<Integer, ArrayList<Edge>> adjList;

    public Graph(){
        this.adjList = new HashMap<>();
    }

    public void initGraph(String nodeFileName,String edgeFileName){
        //读取结点文件，建立邻接表
        List<RowElement> rows = null;
        rows = CsvUtil.readCSV(nodeFileName);
        int id=-1;
        for(RowElement row:rows){
            id=Integer.parseInt(row.getCol(0));
            adjList.put(id,new ArrayList<Edge>());
        }
        //读取边文件，往邻接表中添加边结点
        rows = CsvUtil.readCSV(edgeFileName);
        int tail=-1,head=-1;
        double length=0.0,score=0.0;
        for(RowElement row:rows){
            tail = Integer.parseInt(row.getCol(0));
            head = Integer.parseInt(row.getCol(1));
            length = Double.parseDouble(row.getCol(2));
            score = Double.parseDouble(row.getCol(3));
            Edge edge1 = new Edge(tail,head,length,score);
            adjList.get(tail).add(edge1);
            Edge edge2 = new Edge(head,tail,length,score);
            adjList.get(head).add(edge2);
        }
    }

    public HashMap<Integer, ArrayList<Edge>> getAdjList(){
        return this.adjList;
    }

    public void addPoi(String poiEdgeFileName){
        List<RowElement> rows = null;
        rows = CsvUtil.readCSV(poiEdgeFileName);
        int id=0;
        int tail=-1,head=-1;
        for(RowElement row:rows){
            id = Integer.parseInt(row.getCol(0));
            tail = Integer.parseInt(row.getCol(1));
            head = Integer.parseInt(row.getCol(2));
            for(Edge edge: adjList.get(tail)){
                if(edge.getHead()==head){
                    edge.addPoi(id);
                }
            }
            for(Edge edge: adjList.get(head)){
                if(edge.getHead()==tail){
                    edge.addPoi(id);
                }
            }
        }
    }

    public HashMap<Integer,HashMap<String,Object>> getPoiDict(String poiFileName){
        List<RowElement> rows = null;
        HashMap<Integer,HashMap<String,Object>> poi_dict = new HashMap<>();
        HashMap<String,Object> poiAttrs = null;
        rows = CsvUtil.readCSV(poiFileName);
        int id;
        String typecode, name;
        double rating,longitude,latitude;
        for(RowElement row:rows) {
            id = Integer.parseInt(row.getCol(0));
            typecode = row.getCol(1);
            longitude = Double.parseDouble(row.getCol(2));
            latitude = Double.parseDouble(row.getCol(3));
            name = row.getCol(4);
            rating = Double.parseDouble(row.getCol(5));
            poiAttrs = new HashMap<>();
            poiAttrs.put("typecode",typecode);
            poiAttrs.put("rating",rating);
            poiAttrs.put("lng",longitude);
            poiAttrs.put("lat",latitude);
            poiAttrs.put("name",name);
            poi_dict.put(id,poiAttrs);
        }
        return poi_dict;
    }

    public void computEdgeScore(HashMap<Integer,HashMap<String,Object>> poi_dict,String queryCode){
        String typeCode;
        double score,similarity,rating;
        HashMap<String,Object> poiAttrs;
        for(Integer node:adjList.keySet()){
            for(Edge edge:adjList.get(node)){
                score=0;
                for(Integer id:edge.getPois()){
                    poiAttrs = poi_dict.get(id);
                    typeCode = (String)poiAttrs.get("typecode");
                    rating = (double)poiAttrs.get("rating");
                    similarity = computSimilarity(queryCode,typeCode);
                    score+=similarity*rating;
                }
                edge.setScore(score);
            }
        }

    }

    public double computSimilarity(String queryCode,String targetCode){
        double similarity;
        //用户指定的是一个大类
        if(queryCode.charAt(2)=='0' && queryCode.charAt(3)=='0'){
            if(queryCode.charAt(0)==targetCode.charAt(0) && queryCode.charAt(1)==targetCode.charAt(1)){//属于一个大类
                similarity=(double)1/(double)2;
            }
            else
                similarity=0;
        }
        //用户指定的是一个中类
        else if(queryCode.charAt(4)=='0' && queryCode.charAt(5)=='0'){
            if(queryCode.charAt(0)==targetCode.charAt(0) && queryCode.charAt(1)==targetCode.charAt(1)){//属于一个大类
                if(queryCode.charAt(2)==targetCode.charAt(2) && queryCode.charAt(3)==targetCode.charAt(3))//属于一个中类
                    similarity = (double)4/(double)5;
                else
                    similarity=(double)2/(double)5;
            }
            else
                similarity=0;
        }
        else{//用户指定的是一个小类
            if(queryCode.equals(targetCode))
                similarity=1;
            else if(queryCode.charAt(0)==targetCode.charAt(0) && queryCode.charAt(1)==targetCode.charAt(1)){
                if(queryCode.charAt(2)==targetCode.charAt(2) && queryCode.charAt(3)==targetCode.charAt(3))
                    similarity = (double)2/(double)3;
                else
                    similarity=(double)1/(double)3;
            }
            else
                similarity=0;
        }
        return similarity;
    }

    public HashMap<Integer,HashMap<String,Double>> getNodeDict(String nodeFileName){
        List<RowElement> rows = null;
        HashMap<Integer,HashMap<String,Double>> node_dict = new HashMap<>();
        HashMap<String,Double> nodeAttrs = null;
        rows = CsvUtil.readCSV(nodeFileName);
        int id;
        double x,y;
        for(RowElement row:rows) {
            id = Integer.parseInt(row.getCol(0));
            x = Double.parseDouble(row.getCol(1));
            y = Double.parseDouble(row.getCol(2));
            nodeAttrs = new HashMap<>();
            nodeAttrs.put("x",x);
            nodeAttrs.put("y",y);
            node_dict.put(id,nodeAttrs);
        }
        return node_dict;
    }

    public ArrayList<String> getCodeList(String codeFileName){
        List<RowElement> rows = null;
        ArrayList<String> codes = new ArrayList<>();
        String code;
        rows = CsvUtil.readCSV(codeFileName);
        for(RowElement row:rows) {
            code = row.getCol(0);
            codes.add(code);
        }
        return codes;
    }
}
