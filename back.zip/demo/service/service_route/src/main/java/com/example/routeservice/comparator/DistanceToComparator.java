package com.example.routeservice.comparator;


import com.example.routeservice.algorithm.DistanceTo;

import java.util.Comparator;

public class DistanceToComparator implements Comparator<DistanceTo> {
    @Override
    public int compare(DistanceTo o1, DistanceTo o2) {
        return o1.getDistance()>o2.getDistance()? 1:(o1.getDistance()<o2.getDistance()? -1:0);
    }
}
