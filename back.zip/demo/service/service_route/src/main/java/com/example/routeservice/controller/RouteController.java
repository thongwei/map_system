package com.example.routeservice.controller;

import com.example.routeservice.commonutils.R;
import com.example.routeservice.graph.Keyword;
import com.example.routeservice.graph.Node;
import com.example.routeservice.graph.POI;
import com.example.routeservice.graph.Path;
import com.example.routeservice.service.impl.RouteServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/routeservice/route")
@CrossOrigin
public class RouteController {
    @Autowired
    private RouteServiceImpl routeService;

    @GetMapping("queryScoreRoute")
    public R queryScoreRoute(@RequestParam String startLng, @RequestParam String startLat,
                                @RequestParam String keyword, @RequestParam String delta){
        double x1 = Double.parseDouble(startLng);
        double y1 = Double.parseDouble(startLat);
        double e = Double.parseDouble(delta);
        Path path1 = null, path2 = null;
        long startTime1,endTime1,time1,startTime2,endTime2,time2;
        startTime1 = System.currentTimeMillis();
        path1 = routeService.queryScoreRoute(x1, y1, keyword, e);
        endTime1 = System.currentTimeMillis();
        time1 = endTime1-startTime1;
        startTime2 = System.currentTimeMillis();
        path2 = routeService.queryScoreRoute_baseline(x1, y1, keyword, e);
        endTime2 = System.currentTimeMillis();
        time2 = endTime2-startTime2;
        return R.ok().data("path1",path1).data("time1",time1).data("path2",path2).data("time2",time2);
    }

    @GetMapping("queryDensityRoute")
    public R queryDensityRoute(@RequestParam String startLng, @RequestParam String startLat,
                                @RequestParam String endLng, @RequestParam String endLat,
                                @RequestParam String keyword, @RequestParam String delta){
        double x1 = Double.parseDouble(startLng);
        double y1 = Double.parseDouble(startLat);
        double x2 = Double.parseDouble(endLng);
        double y2 = Double.parseDouble(endLat);
        double e = Double.parseDouble(delta);

        Path path1 = null, path2 = null, path3 = null;
        long startTime1,endTime1,time1,startTime2,endTime2,time2,startTime3,endTime3,time3;
        startTime1 = System.currentTimeMillis();
        path1 = routeService.queryDensityRoute(x1, y1, x2, y2, keyword, e);
        endTime1 = System.currentTimeMillis();
        time1 = endTime1-startTime1;
        for(int i=0;i<path1.getNodes().size();i++){
            Node node = path1.getNodes().get(i);
            node.setX(node.getX()+0.0001);
            node.setY(node.getY()+0.0001);
        }
        for(int i=0;i<path1.getPois().size();i++){
            POI poi = path1.getPois().get(i);
            poi.setX(poi.getX()+0.0001);
            poi.setY(poi.getY()+0.0001);
        }

        startTime2 = System.currentTimeMillis();
        path2 = routeService.queryDensityRoute_baseline(x1, y1, x2, y2, keyword, e);
        endTime2 = System.currentTimeMillis();
        time2 = endTime2-startTime2;
        for(int i=0;i<path2.getNodes().size();i++){
            Node node = path2.getNodes().get(i);
            node.setX(node.getX()+0.0002);
            node.setY(node.getY()+0.0002);
        }
        for(int i=0;i<path2.getPois().size();i++){
            POI poi = path2.getPois().get(i);
            poi.setX(poi.getX()+0.0002);
            poi.setY(poi.getY()+0.0002);
        }

        startTime3 = System.currentTimeMillis();
        path3 = routeService.queryDensityRoute_Astar(x1, y1, x2, y2, keyword, e);
        endTime3 = System.currentTimeMillis();
        time3 = endTime3-startTime3;
        return R.ok().data("path1",path1).data("time1",time1).data("path2",path2).data("time2",time2).data("path3",path3).data("time3",time3);
    }

    @GetMapping("getKeywordList")
    public R getKeywords(){
        ArrayList<Keyword> keywords = routeService.getKeywords();
        return R.ok().data("keywords",keywords);
    }

}
