package com.example.routeservice.algorithm;


import com.example.routeservice.comparator.LSComparator;
import com.example.routeservice.graph.Edge;
import com.example.routeservice.graph.Graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.PriorityQueue;


public class RangeQuery {

    //穷举+pruning
    public ArrayList<Integer> prune1(Graph G, int start, String code, double e, HashMap<Integer,HashMap<String,Object>> poi_dict){
        G.computEdgeScore(poi_dict,code);//计算所有边的分数
        double maxUnitScore = getMaxUnitScore(G,start,e);//首先得到范围内最大单位分数
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();
        HashMap<Integer, ArrayList<Integer>> paths=new HashMap<>();
        int pathId=0;
        ArrayList<Integer> path=new ArrayList<>();
        path.add(start);
        if(maxUnitScore==-1 || maxUnitScore==0){//说明该范围内没有边或者所有边都是0分
            return path;
        }
        paths.put(pathId,path);
        LSComparator comparator = new LSComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        NodeLabel label = new NodeLabel(pathId,start,0,0);
        Q.add(label);
        ArrayList<Integer> cur_path = null;
        ArrayList<Integer> result=null;
        int neiNode;
        int flag;
        double dist,score;
        double maxScore=-1;
        while(!Q.isEmpty()){
            label = Q.poll();
            if(label.getScore()+(e-label.getLength())*maxUnitScore <= maxScore){
                paths.remove(label.getPathId());
                continue;
            }
            cur_path = paths.get(label.getPathId());
            flag=0;
            for(Edge edge:adjList.get(label.getNode())){
                neiNode = edge.getHead();
                if(cur_path.contains(neiNode)==false) {
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if ((dist <= e)  && ((score+(e-dist)*maxUnitScore)>maxScore)) {
                        flag = 1;//当前路径(即标签)被扩展了
                        pathId += 1;
                        ArrayList<Integer> new_path = new ArrayList<>();
                        new_path.addAll(cur_path);
                        new_path.add(neiNode);
                        paths.put(pathId, new_path);
                        NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                        Q.add(nodeLabel);
                    }
                }
            }
            if(flag==0 && label.getScore()>maxScore){//此label无法被扩展了
                maxScore=label.getScore();
                result=cur_path;
            }
            paths.remove(label.getPathId());
        }
        return result;
    }

    //穷举
    public ArrayList<Integer> prune2(Graph G, int start, String code, double e, HashMap<Integer,HashMap<String,Object>> poi_dict){
        G.computEdgeScore(poi_dict,code);//计算所有边的分数
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();
        HashMap<Integer, ArrayList<Integer>> paths=new HashMap<>();
        int pathId=0;
        ArrayList<Integer> path=new ArrayList<>();
        path.add(start);
        paths.put(pathId,path);
        LSComparator comparator = new LSComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        NodeLabel label = new NodeLabel(pathId,start,0,0);
        Q.add(label);
        ArrayList<Integer> cur_path = null;
        ArrayList<Integer> result=null;
        int neiNode;
        int flag;
        double dist,score;
        double maxScore=-1;
        while(!Q.isEmpty()){
            label = Q.poll();
            cur_path = paths.get(label.getPathId());
            flag=0;
            for(Edge edge:adjList.get(label.getNode())){
                neiNode = edge.getHead();
                if(cur_path.contains(neiNode)==false) {
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if (dist <= e) {
                        flag = 1;//当前路径(即标签)被扩展了
                        pathId += 1;
                        ArrayList<Integer> new_path = new ArrayList<>();
                        new_path.addAll(cur_path);
                        new_path.add(neiNode);
                        paths.put(pathId, new_path);
                        NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                        Q.add(nodeLabel);
                    }
                }
            }
            if(flag==0 && label.getScore()>maxScore){//此label无法被扩展了
                maxScore=label.getScore();
                result=cur_path;
            }
            paths.remove(label.getPathId());
        }
        return result;
    }

    //top-k+pruning+dominate
    public ArrayList<Integer> prune3(Graph G, int start, String code, double e, int k, HashMap<Integer,HashMap<String,Object>> poi_dict){
        G.computEdgeScore(poi_dict,code);//计算所有边的分数
        double maxUnitScore = getMaxUnitScore(G,start,e);//首先得到范围内最大单位分数
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();//得到图的邻接表
        HashMap<Integer,LinkedList<NodeLabel>> node_labels = new HashMap<>();//保存每个节点上的标签
        for(Integer node:G.getAdjList().keySet()){
            node_labels.put(node,new LinkedList<>());
        }
        HashMap<Integer, ArrayList<Integer>> paths=new HashMap<>();
        LSComparator comparator = new LSComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        int pathId=0;
        ArrayList<Integer> path=new ArrayList<>();
        path.add(start);
        if(maxUnitScore==-1 || maxUnitScore==0){//说明该范围内没有边或者所有边都是0分
            return path;
        }
        paths.put(pathId,path);
        NodeLabel label = new NodeLabel(pathId,start,0,0);
        Q.add(label);
        node_labels.get(label.getNode()).addFirst(label);//头插法
        ArrayList<Integer> cur_path = null;
        ArrayList<Integer> result=null;
        int neiNode;
        int flag,dominate;//是否被扩展了
        double dist,score;
        double maxScore=-1,us,minUS;
        NodeLabel minLabel;
        LinkedList<NodeLabel> labels;
        while(!Q.isEmpty()){
            label = Q.poll();
//            node_labels.get(label.getNode()).remove(label);
            if(label.getScore()+(e-label.getLength())*maxUnitScore <= maxScore){
                paths.remove(label.getPathId());
                continue;
            }
            cur_path = paths.get(label.getPathId());
            flag=0;
            for(Edge edge:adjList.get(label.getNode())){
                neiNode = edge.getHead();//邻接点
                if(cur_path.contains(neiNode)==false) {//避免走环
                    dominate=0;
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if ((dist <= e)  && ((score+(e-dist)*maxUnitScore)>maxScore)) {//距离和分数都满足要求
                        labels = node_labels.get(neiNode);//邻接点上的所有标签
                        for(NodeLabel label1:labels){
                            if(label1.getLength()<=dist && label1.getScore()>=score){
                                dominate=1;//被dominate了
                                break;
                            }
                        }
                        if(dominate==0){//没有被dominate
                            if(labels.size()==k){//如果标签数满了
                                us = score/dist;
                                minUS = labels.get(0).getScore()/labels.get(0).getLength();
                                minLabel = labels.get(0);
                                for(NodeLabel label2:labels){//找邻接点上单位分数最小的标签
                                    if(label2.getScore()/label2.getLength()<minUS){
                                        minUS = label2.getScore()/label2.getLength();
                                        minLabel = label2;
                                    }
                                }
                                if(us>minUS){
                                    labels.remove(minLabel);//移除旧标签
                                    flag = 1;//当前路径(即标签)被扩展了
                                    pathId += 1;
                                    ArrayList<Integer> new_path = new ArrayList<>();
                                    new_path = (ArrayList<Integer>)cur_path.clone();
                                    new_path.add(neiNode);
                                    paths.put(pathId, new_path);
                                    NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                                    Q.add(nodeLabel);
                                    labels.addFirst(nodeLabel);//添加新标签
                                }
                            }
                            else{
                                flag = 1;//当前路径(即标签)被扩展了
                                pathId += 1;
                                ArrayList<Integer> new_path = new ArrayList<>();
                                new_path = (ArrayList<Integer>)cur_path.clone();
                                new_path.add(neiNode);
                                paths.put(pathId, new_path);
                                NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                                Q.add(nodeLabel);
                                labels.addFirst(nodeLabel);//添加新标签
                            }
                        }
                    }
                }
            }
            if(flag==0 && label.getScore()>maxScore){//此label无法被扩展了
                maxScore=label.getScore();
                result=cur_path;
            }
            paths.remove(label.getPathId());
        }
        return result;
    }

    //top-k
    public ArrayList<Integer> prune6(Graph G, int start, String code, double e, int k, HashMap<Integer,HashMap<String,Object>> poi_dict){
        G.computEdgeScore(poi_dict,code);//计算所有边的分数
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();//得到图的邻接表
        HashMap<Integer,LinkedList<NodeLabel>> node_labels = new HashMap<>();//保存每个节点上的标签
        for(Integer node:G.getAdjList().keySet()){
            node_labels.put(node,new LinkedList<>());
        }
        HashMap<Integer, ArrayList<Integer>> paths=new HashMap<>();
        LSComparator comparator = new LSComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        int pathId=0;
        ArrayList<Integer> path=new ArrayList<>();
        path.add(start);
        paths.put(pathId,path);
        NodeLabel label = new NodeLabel(pathId,start,0,0);
        Q.add(label);
        node_labels.get(label.getNode()).addFirst(label);//头插法
        ArrayList<Integer> cur_path = null;
        ArrayList<Integer> result=null;
        int neiNode;
        int flag;//是否被扩展了
        double dist,score;
        double maxScore=-1,us,minUS;
        NodeLabel minLabel;
        LinkedList<NodeLabel> labels;
        while(!Q.isEmpty()){
            label = Q.poll();
//            node_labels.get(label.getNode()).remove(label);
            cur_path = paths.get(label.getPathId());
            flag=0;
            for(Edge edge:adjList.get(label.getNode())){
                neiNode = edge.getHead();//邻接点
                if(cur_path.contains(neiNode)==false) {//避免走环
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if (dist <= e) {//距离和分数都满足要求
                        labels = node_labels.get(neiNode);//邻接点上的所有标签
                        if(labels.size()==k){//如果标签数满了
                            us = score/dist;
                            minUS = labels.get(0).getScore()/labels.get(0).getLength();
                            minLabel = labels.get(0);
                            for(NodeLabel label2:labels){//找邻接点上单位分数最小的标签
                                if(label2.getScore()/label2.getLength()<minUS){
                                    minUS = label2.getScore()/label2.getLength();
                                    minLabel = label2;
                                }
                            }
                            if(us>minUS){
                                labels.remove(minLabel);//移除旧标签
                                flag = 1;//当前路径(即标签)被扩展了
                                pathId += 1;
                                ArrayList<Integer> new_path = new ArrayList<>();
                                new_path = (ArrayList<Integer>)cur_path.clone();
                                new_path.add(neiNode);
                                paths.put(pathId, new_path);
                                NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                                Q.add(nodeLabel);
                                labels.addFirst(nodeLabel);//添加新标签
                            }
                        }
                        else{
                            flag = 1;//当前路径(即标签)被扩展了
                            pathId += 1;
                            ArrayList<Integer> new_path = new ArrayList<>();
                            new_path = (ArrayList<Integer>)cur_path.clone();
                            new_path.add(neiNode);
                            paths.put(pathId, new_path);
                            NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                            Q.add(nodeLabel);
                            labels.addFirst(nodeLabel);//添加新标签
                        }
                    }
                }
            }
            if(flag==0 && label.getScore()>maxScore){//此label无法被扩展了
                maxScore=label.getScore();
                result=cur_path;
            }
            paths.remove(label.getPathId());
        }
        return result;
    }

    //贪心算法
    public ArrayList<Integer> simpleGreedy(Graph G, int start, String code, double e, HashMap<Integer,HashMap<String,Object>> poi_dict){
        G.computEdgeScore(poi_dict,code);
        ArrayList<Integer> path = new ArrayList<>();
        double length;
        int curNode,neiNode;
        int maxNode;
        double maxScore;
        Edge maxEdge=null;
        path.add(start);
        length=0;
        while(length<=e){
            curNode = path.get(path.size()-1);
            maxNode=-1;
            maxScore=-1;
            for(Edge edge:G.getAdjList().get(curNode)){
                neiNode = edge.getHead();
                if(path.contains(neiNode)==false){
                    if(edge.getScore()>maxScore){
                        maxScore = edge.getScore();
                        maxNode = neiNode;
                        maxEdge = edge;
                    }
                }
            }
            if(maxNode==-1){
                return path;
            }
            path.add(maxNode);
            length+=maxEdge.getLength();
        }
        path.remove(path.size()-1);
        return path;
    }

    public long prune3Iters(Graph G, int start, String code, double e, int k, HashMap<Integer,HashMap<String,Object>> poi_dict){
        long iters=0;
        G.computEdgeScore(poi_dict,code);//计算所有边的分数
        double maxUnitScore = getMaxUnitScore(G,start,e);//首先得到范围内最大单位分数
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();//得到图的邻接表
        HashMap<Integer,LinkedList<NodeLabel>> node_labels = new HashMap<>();//保存每个节点上的标签
        for(Integer node:G.getAdjList().keySet()){
            node_labels.put(node,new LinkedList<>());
        }
        HashMap<Integer, ArrayList<Integer>> paths=new HashMap<>();
        LSComparator comparator = new LSComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        int pathId=0;
        ArrayList<Integer> path=new ArrayList<>();
        path.add(start);
        if(maxUnitScore==-1 || maxUnitScore==0){//说明该范围内没有边或者所有边都是0分
            return 0;
        }
        paths.put(pathId,path);
        NodeLabel label = new NodeLabel(pathId,start,0,0);
        Q.add(label);
        node_labels.get(label.getNode()).addFirst(label);//头插法
        ArrayList<Integer> cur_path = null;
        ArrayList<Integer> result=null;
        int neiNode;
        int flag,dominate;//是否被扩展了
        double dist,score;
        double maxScore=-1,us,minUS;
        NodeLabel minLabel;
        LinkedList<NodeLabel> labels;
        while(!Q.isEmpty()){
            iters+=1;
            label = Q.poll();
//            node_labels.get(label.getNode()).remove(label);
            if(label.getScore()+(e-label.getLength())*maxUnitScore <= maxScore){
                paths.remove(label.getPathId());
                continue;
            }
            cur_path = paths.get(label.getPathId());
            flag=0;
            for(Edge edge:adjList.get(label.getNode())){
                neiNode = edge.getHead();//邻接点
                if(cur_path.contains(neiNode)==false) {//避免走环
                    dominate=0;
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if ((dist <= e)  && ((score+(e-dist)*maxUnitScore)>maxScore)) {//距离和分数都满足要求
                        labels = node_labels.get(neiNode);//邻接点上的所有标签
                        for(NodeLabel label1:labels){
                            if(label1.getLength()<=dist && label1.getScore()>=score){
                                dominate=1;//被dominate了
                                break;
                            }
                        }
                        if(dominate==0){//没有被dominate
                            if(labels.size()==k){//如果标签数满了
                                us = score/dist;
                                minUS = labels.get(0).getScore()/labels.get(0).getLength();
                                minLabel = labels.get(0);
                                for(NodeLabel label2:labels){//找邻接点上单位分数最小的标签
                                    if(label2.getScore()/label2.getLength()<minUS){
                                        minUS = label2.getScore()/label2.getLength();
                                        minLabel = label2;
                                    }
                                }
                                if(us>minUS){
                                    labels.remove(minLabel);//移除旧标签
                                    flag = 1;//当前路径(即标签)被扩展了
                                    pathId += 1;
                                    ArrayList<Integer> new_path = new ArrayList<>();
                                    new_path = (ArrayList<Integer>)cur_path.clone();
                                    new_path.add(neiNode);
                                    paths.put(pathId, new_path);
                                    NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                                    Q.add(nodeLabel);
                                    labels.addFirst(nodeLabel);//添加新标签
                                }
                            }
                            else{
                                flag = 1;//当前路径(即标签)被扩展了
                                pathId += 1;
                                ArrayList<Integer> new_path = new ArrayList<>();
                                new_path = (ArrayList<Integer>)cur_path.clone();
                                new_path.add(neiNode);
                                paths.put(pathId, new_path);
                                NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                                Q.add(nodeLabel);
                                labels.addFirst(nodeLabel);//添加新标签
                            }
                        }
                    }
                }
            }
            if(flag==0 && label.getScore()>maxScore){//此label无法被扩展了
                maxScore=label.getScore();
                result=cur_path;
            }
            paths.remove(label.getPathId());
        }
        return iters;
    }

    public int prune6Iters(Graph G, int start, String code, double e, int k, HashMap<Integer,HashMap<String,Object>> poi_dict){
        int iters=0;
        G.computEdgeScore(poi_dict,code);//计算所有边的分数
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();//得到图的邻接表
        HashMap<Integer,LinkedList<NodeLabel>> node_labels = new HashMap<>();//保存每个节点上的标签
        for(Integer node:G.getAdjList().keySet()){
            node_labels.put(node,new LinkedList<>());
        }
        HashMap<Integer, ArrayList<Integer>> paths=new HashMap<>();
        LSComparator comparator = new LSComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        int pathId=0;
        ArrayList<Integer> path=new ArrayList<>();
        path.add(start);
        paths.put(pathId,path);
        NodeLabel label = new NodeLabel(pathId,start,0,0);
        Q.add(label);
        node_labels.get(label.getNode()).addFirst(label);//头插法
        ArrayList<Integer> cur_path = null;
        ArrayList<Integer> result=null;
        int neiNode;
        int flag;//是否被扩展了
        double dist,score;
        double maxScore=-1,us,minUS;
        NodeLabel minLabel;
        LinkedList<NodeLabel> labels;
        while(!Q.isEmpty()){
            iters+=1;
            label = Q.poll();
//            node_labels.get(label.getNode()).remove(label);
            cur_path = paths.get(label.getPathId());
            flag=0;
            for(Edge edge:adjList.get(label.getNode())){
                neiNode = edge.getHead();//邻接点
                if(cur_path.contains(neiNode)==false) {//避免走环
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if (dist <= e) {//距离和分数都满足要求
                        labels = node_labels.get(neiNode);//邻接点上的所有标签
                        if(labels.size()==k){//如果标签数满了
                            us = score/dist;
                            minUS = labels.get(0).getScore()/labels.get(0).getLength();
                            minLabel = labels.get(0);
                            for(NodeLabel label2:labels){//找邻接点上单位分数最小的标签
                                if(label2.getScore()/label2.getLength()<minUS){
                                    minUS = label2.getScore()/label2.getLength();
                                    minLabel = label2;
                                }
                            }
                            if(us>minUS){
                                labels.remove(minLabel);//移除旧标签
                                flag = 1;//当前路径(即标签)被扩展了
                                pathId += 1;
                                ArrayList<Integer> new_path = new ArrayList<>();
                                new_path = (ArrayList<Integer>)cur_path.clone();
                                new_path.add(neiNode);
                                paths.put(pathId, new_path);
                                NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                                Q.add(nodeLabel);
                                labels.addFirst(nodeLabel);//添加新标签
                            }
                        }
                        else{
                            flag = 1;//当前路径(即标签)被扩展了
                            pathId += 1;
                            ArrayList<Integer> new_path = new ArrayList<>();
                            new_path = (ArrayList<Integer>)cur_path.clone();
                            new_path.add(neiNode);
                            paths.put(pathId, new_path);
                            NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                            Q.add(nodeLabel);
                            labels.addFirst(nodeLabel);//添加新标签
                        }
                    }
                }
            }
            if(flag==0 && label.getScore()>maxScore){//此label无法被扩展了
                maxScore=label.getScore();
                result=cur_path;
            }
            paths.remove(label.getPathId());
        }
        return iters;
    }


    //获取范围内最大单位分数
    public double getMaxUnitScore(Graph G, int start, double e){
        HashMap<Integer,ArrayList<Edge>> adjList = G.getAdjList();
        HashMap<Integer, Double> dist = AlgorithmUtil.multiDijkstra(G,start);
        double length, tempUS, maxUS=-1;
        int neiNode;

        for(Integer node:dist.keySet()){
            length = dist.get(node);
            if(length<e){
                for(Edge edge:adjList.get(node)){
                    neiNode=edge.getHead();
                    if((length+edge.getLength())<=e){
                        tempUS=edge.getScore()/edge.getLength();
                        if(tempUS>maxUS){
                            maxUS=tempUS;
                        }
                    }
                }
            }
        }
        return maxUS;
    }


}
