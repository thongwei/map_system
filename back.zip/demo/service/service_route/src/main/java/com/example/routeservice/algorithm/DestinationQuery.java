package com.example.routeservice.algorithm;

import com.example.routeservice.comparator.DComparator;
import com.example.routeservice.comparator.LComparator;
import com.example.routeservice.graph.Edge;
import com.example.routeservice.graph.Graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.PriorityQueue;

public class DestinationQuery {

    public ArrayList<Integer> bruteForce(Graph G, int start, int end, double e) {
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();//得到图的邻接表
        HashMap<Integer, Double> dists = AlgorithmUtil.multiDijkstra(G,end);
        double us = getMaxUnitScore(G,start,e);

        HashMap<Integer, ArrayList<Integer>> paths = new HashMap<>();
        LComparator comparator = new LComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        int pathId = 0;
        ArrayList<Integer> path = new ArrayList<>();
        path.add(start);
        paths.put(pathId, path);
        NodeLabel label = new NodeLabel(pathId, start, 0, 0);
        Q.add(label);
        ArrayList<Integer> cur_path = null, result = null;
        int neiNode;
        double dist, score, maxDensity=-1;
        while (!Q.isEmpty()) {
            label = Q.poll();
            cur_path = paths.get(label.getPathId());
            if(label.getNode()==end) {
                if(label.getScore()/label.getLength()> maxDensity){
                    maxDensity = label.getScore()/label.getLength();
                    result = cur_path;
                }
                paths.remove(label.getPathId());
                continue;
            }
            if((label.getScore()+us*(e-label.getLength()))/(label.getLength()+dists.get(label.getNode()))<=maxDensity){
                continue;
            }
            for (Edge edge : adjList.get(label.getNode())) {
                neiNode = edge.getHead();//邻接点
                if (cur_path.contains(neiNode) == false) {//确保走简单路径
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if(dist>e || (dist+dists.get(neiNode))>e){
                        continue;
                    }
                    if((score+us*(e-dist))/(dist+dists.get(neiNode))<=maxDensity){
                        continue;
                    }
                    pathId += 1;
                    ArrayList<Integer> new_path = new ArrayList<>();
                    new_path = (ArrayList<Integer>) cur_path.clone();
                    new_path.add(neiNode);
                    paths.put(pathId, new_path);
                    NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                    Q.add(nodeLabel);
                }
            }
            paths.remove(label.getPathId());
        }
        return result;
    }

    //加上了剪枝，效果会好一点
    public ArrayList<Integer> A_star(Graph G, int start, int end, String code, double e, HashMap<Integer,HashMap<String,Object>> poi_dict) {
        G.computEdgeScore(poi_dict,code);//计算所有边的分数
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();//得到图的邻接表
        HashMap<String, Object> dijks = AlgorithmUtil.multiDijkstra1(G, end);
        HashMap<Integer,Double> dists = (HashMap<Integer,Double>)dijks.get("dist");
        HashMap<Integer, Integer> paths_prefix = (HashMap<Integer, Integer>) dijks.get("paths");
        ArrayList<Integer> shortest_path = AlgorithmUtil.getPath(G,end,start,paths_prefix);
        double us = getMaxUnitScore(G,start,e);
        double density;

        HashMap<Integer, ArrayList<Integer>> paths = new HashMap<>();
        DComparator comparator = new DComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        int pathId = 0;
        ArrayList<Integer> path = new ArrayList<>();
        path.add(start);
        paths.put(pathId, path);
        density = (us*e)/dists.get(start);
        NodeLabel label = new NodeLabel(pathId, start, 0, 0, density);
        Q.add(label);
        ArrayList<Integer> cur_path, result = null ;
        int neiNode;
        double dist, score, maxDensity=-1;
        dist = dists.get(start);
        score = AlgorithmUtil.getPathInfo(G,shortest_path,"score");
        maxDensity = score/dist;
        result = shortest_path;
        while (!Q.isEmpty()) {
            label = Q.poll();
            cur_path = paths.get(label.getPathId());
            if(label.getNode()==end){
                result = cur_path;
                break;
            }
            if((label.getScore()+(e-label.getLength())*us)/(label.getLength()+dists.get(label.getNode()))<=maxDensity){
                continue;
            }
            for (Edge edge : adjList.get(label.getNode())) {
                neiNode = edge.getHead();//邻接点
                if (cur_path.contains(neiNode) == false) {//走简单路径
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if(neiNode==end){
                        density = score/dist;
                    }else{
                        density = score/dist+(us*(e-dist))/dists.get(neiNode);
                    }
                    if(dist>e || (dist+dists.get(neiNode))>e){
                        continue;
                    }
                    if((score+(e-dist)*us)/(dist+dists.get(neiNode))<=maxDensity){
                        continue;
                    }
                    if(neiNode==end && density>maxDensity){
                        maxDensity = density;
                    }
                    pathId += 1;
                    ArrayList<Integer> new_path = new ArrayList<>();
                    new_path = (ArrayList<Integer>) cur_path.clone();
                    new_path.add(neiNode);
                    paths.put(pathId, new_path);
                    NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score, density);
                    Q.add(nodeLabel);
                }
            }
            paths.remove(label.getPathId());
        }
        return result;
    }

    public void computL_S(Graph G){
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();
        for(Integer node:adjList.keySet()) {
            for (Edge edge : adjList.get(node)) {
                if(edge.getScore()==0.0){
                    edge.setL_s(edge.getLength()/0.5);
                }
                else{
                    edge.setL_s(edge.getLength()/edge.getScore());
                }
            }
        }
    }

    public ArrayList<Integer> labelSetting(Graph G, int start, int end, String code, double e, HashMap<Integer,HashMap<String,Object>> poi_dict) {
        G.computEdgeScore(poi_dict,code);//计算所有边的分数
        computL_S(G);//计算 长度/分数 作为边权
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();//得到图的邻接表
        //HashMap<Integer, Double> dists = AlgorithmUtil.multiDijkstra(G,end);
        HashMap<String, Object> dijks = AlgorithmUtil.multiDijkstra1(G, end);
        HashMap<Integer,Double> dists = (HashMap<Integer,Double>)dijks.get("dist");
        HashMap<Integer, Integer> paths_prefix = (HashMap<Integer, Integer>) dijks.get("paths");
        ArrayList<Integer> shortest_path = AlgorithmUtil.getPath(G,end,start,paths_prefix);

        HashMap<Integer, ArrayList<Integer>> paths = new HashMap<>();
        HashMap<Integer, LinkedList<NodeLabel>> node_labels = new HashMap<>();
        for(Integer node:G.getAdjList().keySet()){
            node_labels.put(node,new LinkedList<>());//保存每个结点上的标签
        }
        LComparator comparator = new LComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        int pathId = 0;
        ArrayList<Integer> path = new ArrayList<>();
        path.add(start);
        paths.put(pathId, path);
        NodeLabel label, minLabel;
        label = new NodeLabel(pathId, start, 0, 0);//注意这里的分数是l_s
        Q.add(label);
        node_labels.get(start).addFirst(label);
        ArrayList<Integer> cur_path = null,result = null;
        int neiNode;
        int dominate;
        double dist, score, minL_s=Double.POSITIVE_INFINITY;
        LinkedList<NodeLabel> labels;
        result = shortest_path;
        while (!Q.isEmpty()) {
            label = Q.poll();
            cur_path = paths.get(label.getPathId());
            if(label.getNode()==end) {
                if(label.getScore() < minL_s){
                    result = cur_path;
                    minL_s = label.getScore();
                }
                paths.remove(label.getPathId());
                continue;
            }
            if(label.getLength()>=e){
                break;
            }
            for (Edge edge : adjList.get(label.getNode())) {
                neiNode = edge.getHead();//邻接点
                if (cur_path.contains(neiNode) == false) {//确保走简单路径
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getL_s();
                    if(dist>e || (dist+dists.get(neiNode))>e){
                        continue;
                    }
                    labels = node_labels.get(neiNode);
                    dominate=0;
                    for(NodeLabel nodeLabe2:labels){
                        if(nodeLabe2.getLength()<=dist && nodeLabe2.getScore()<=score){
                            dominate=1;
                            break;
                        }
                    }
                    if(dominate==1){
                        continue;
                    }
                    pathId += 1;
                    ArrayList<Integer> new_path = new ArrayList<>();
                    new_path = (ArrayList<Integer>) cur_path.clone();
                    new_path.add(neiNode);
                    paths.put(pathId, new_path);
                    NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                    Q.add(nodeLabel);
                    labels.addFirst(nodeLabel);
                }
            }
            paths.remove(label.getPathId());
        }
        return result;
    }

    //top-k+pruning+dominate
    public ArrayList<Integer> kNE(Graph G, int start, int end, String code, double e, int k, HashMap<Integer,HashMap<String,Object>> poi_dict) {
        G.computEdgeScore(poi_dict,code);//计算所有边的分数
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();//得到图的邻接表
        HashMap<String, Object> dijks = (HashMap<String, Object>)AlgorithmUtil.multiDijkstra1(G, end);
        HashMap<Integer,Double> dists = (HashMap<Integer,Double>)dijks.get("dist");
        HashMap<Integer, Integer> paths_prefix = (HashMap<Integer, Integer>) dijks.get("paths");
        ArrayList<Integer> shortest_path = AlgorithmUtil.getPath(G,end,start,paths_prefix);
        double us = getMaxUnitScore(G,start,e);

        HashMap<Integer, ArrayList<Integer>> paths = new HashMap<>();
        HashMap<Integer, LinkedList<NodeLabel>> node_labels = new HashMap<>();
        for(Integer node:G.getAdjList().keySet()){
            node_labels.put(node,new LinkedList<>());
        }
        LComparator comparator = new LComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        int pathId = 0;
        ArrayList<Integer> path = new ArrayList<>();
        path.add(start);
        paths.put(pathId, path);
        NodeLabel label, minLabel;
        label = new NodeLabel(pathId, start, 0, 0);
        Q.add(label);
        node_labels.get(start).addFirst(label);
        ArrayList<Integer> cur_path = null,result = null;
        int neiNode;
        int dominate;
        double dist, score, maxDensity=-1, minDensity;
        dist = dists.get(start);
        score = AlgorithmUtil.getPathInfo(G,shortest_path,"score");
        maxDensity = score/dist;
        result = shortest_path;
        LinkedList<NodeLabel> labels;
        while (!Q.isEmpty()) {
            label = Q.poll();
            cur_path = paths.get(label.getPathId());
            if(label.getNode()==end) {
                if(label.getScore()/label.getLength() > maxDensity){
                    result = cur_path;
                    maxDensity = label.getScore()/label.getLength();
                }
                paths.remove(label.getPathId());
                continue;
            }
            if(((label.getScore()+ us*(e-label.getLength()))/(label.getLength()+dists.get(label.getNode())))<=maxDensity){
                continue;
            }
            for (Edge edge : adjList.get(label.getNode())) {
                neiNode = edge.getHead();//邻接点
                if (cur_path.contains(neiNode) == false) {//确保走简单路径
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if(dist>e || (dist+dists.get(neiNode))>e){
                        continue;
                    }
                    if(((score+ us*(e-dist))/(dist+dists.get(neiNode)))<=maxDensity){
                        continue;
                    }
                    labels = node_labels.get(neiNode);
                    dominate=0;
                    for(NodeLabel nodeLabe2:labels){
                        if(nodeLabe2.getLength()<=dist && nodeLabe2.getScore()>=score){
                            dominate=1;
                            break;
                        }
                    }
                    if(dominate==1){
                        continue;
                    }
                    if(labels.size()==k) {
                        minDensity = labels.get(0).getScore() / labels.get(0).getLength();
                        minLabel = labels.get(0);
                        for (NodeLabel label1 : labels) {
                            if (label1.getScore() / label1.getLength() < minDensity) {
                                minDensity = label1.getScore() / label1.getLength();
                                minLabel = label;
                            }
                        }
                        if (score / dist > minDensity) {
                            labels.remove(minLabel);
                            pathId += 1;
                            ArrayList<Integer> new_path = new ArrayList<>();
                            new_path = (ArrayList<Integer>) cur_path.clone();
                            new_path.add(neiNode);
                            paths.put(pathId, new_path);
                            NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                            Q.add(nodeLabel);
                            labels.addFirst(nodeLabel);
                        }
                    }
                    else{
                        pathId += 1;
                        ArrayList<Integer> new_path = new ArrayList<>();
                        new_path = (ArrayList<Integer>) cur_path.clone();
                        new_path.add(neiNode);
                        paths.put(pathId, new_path);
                        NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score);
                        Q.add(nodeLabel);
                        labels.addFirst(nodeLabel);
                    }
                }
            }
            paths.remove(label.getPathId());
        }
        return result;
    }

    //top-k+pruning+dominate+A*
    public ArrayList<Integer> kNE1(Graph G, int start, int end, double e, int k) {
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();//得到图的邻接表
        HashMap<String, Object> dijks = (HashMap<String, Object>)AlgorithmUtil.multiDijkstra1(G, end);
        HashMap<Integer,Double> dists = (HashMap<Integer,Double>)dijks.get("dist");
        HashMap<Integer, Integer> paths_prefix = (HashMap<Integer, Integer>) dijks.get("paths");
        ArrayList<Integer> shortest_path = AlgorithmUtil.getPath(G,end,start,paths_prefix);
        double us = getMaxUnitScore(G,start,e);
        double density;

        HashMap<Integer, ArrayList<Integer>> paths = new HashMap<>();
        HashMap<Integer, LinkedList<NodeLabel>> node_labels = new HashMap<>();
        for(Integer node:G.getAdjList().keySet()){
            node_labels.put(node,new LinkedList<>());
        }
        DComparator comparator = new DComparator();
        PriorityQueue<NodeLabel> Q = new PriorityQueue<NodeLabel>(comparator);
        int pathId = 0;
        ArrayList<Integer> path = new ArrayList<>();
        path.add(start);
        paths.put(pathId, path);
        NodeLabel label, minLabel;
        density = (us*e)/dists.get(start);
        label = new NodeLabel(pathId, start, 0, 0,density);
        Q.add(label);
        node_labels.get(start).addFirst(label);
        ArrayList<Integer> cur_path = null,result = null;
        int neiNode;
        int dominate;
        double dist, score, maxDensity=-1, minDensity;
        dist = dists.get(start);
        score = AlgorithmUtil.getPathInfo(G,shortest_path,"score");
        maxDensity = score/dist;
        result = shortest_path;
        LinkedList<NodeLabel> labels;
        while (!Q.isEmpty()) {
            label = Q.poll();
            cur_path = paths.get(label.getPathId());
            if(label.getNode()==end) {
                if(label.getScore()/label.getLength() > maxDensity){
                    result = cur_path;
                    maxDensity = label.getScore()/label.getLength();
                }
                paths.remove(label.getPathId());
                continue;
            }
            if(((label.getScore()+ us*(e-label.getLength()))/(label.getLength()+dists.get(label.getNode())))<=maxDensity){
                continue;
            }
            for (Edge edge : adjList.get(label.getNode())) {
                neiNode = edge.getHead();//邻接点
                if (cur_path.contains(neiNode) == false) {//确保走简单路径
                    dist = label.getLength() + edge.getLength();
                    score = label.getScore() + edge.getScore();
                    if(neiNode==end){
                        density = score/dist;
                    }else{
                        density = score/dist+(us*(e-dist))/dists.get(neiNode);
                    }
                    if(dist>e || (dist+dists.get(neiNode))>e){
                        continue;
                    }
                    if(((score+ us*(e-dist))/(dist+dists.get(neiNode)))<=maxDensity){
                        continue;
                    }
                    labels = node_labels.get(neiNode);
                    dominate=0;
                    for(NodeLabel nodeLabe2:labels){
                        if(nodeLabe2.getLength()<=dist && nodeLabe2.getScore()>=score){
                            dominate=1;
                            break;
                        }
                    }
                    if(dominate==1){
                        continue;
                    }
                    if(labels.size()==k) {
                        minDensity = labels.get(0).getScore() / labels.get(0).getLength();
                        minLabel = labels.get(0);
                        for (NodeLabel label1 : labels) {
                            if (label1.getScore() / label1.getLength() < minDensity) {
                                minDensity = label1.getScore() / label1.getLength();
                                minLabel = label;
                            }
                        }
                        if (score / dist > minDensity) {
                            labels.remove(minLabel);
                            pathId += 1;
                            ArrayList<Integer> new_path = new ArrayList<>();
                            new_path = (ArrayList<Integer>) cur_path.clone();
                            new_path.add(neiNode);
                            paths.put(pathId, new_path);
                            NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score,density);
                            Q.add(nodeLabel);
                            labels.addFirst(nodeLabel);
                        }
                    }
                    else{
                        pathId += 1;
                        ArrayList<Integer> new_path = new ArrayList<>();
                        new_path = (ArrayList<Integer>) cur_path.clone();
                        new_path.add(neiNode);
                        paths.put(pathId, new_path);
                        NodeLabel nodeLabel = new NodeLabel(pathId, neiNode, dist, score,density);
                        Q.add(nodeLabel);
                        labels.addFirst(nodeLabel);
                    }
                }
            }
            paths.remove(label.getPathId());
        }
        return result;
    }

    //获取范围内最大单位分数
    public double getMaxUnitScore(Graph G, int start, double e){
        HashMap<Integer,ArrayList<Edge>> adjList = G.getAdjList();
        HashMap<Integer, Double> dist = AlgorithmUtil.multiDijkstra(G,start);
        double length, tempUS, maxUS=-1;
        int neiNode;

        for(Integer node:dist.keySet()){
            length = dist.get(node);
            if(length<e){
                for(Edge edge:adjList.get(node)){
                    neiNode=edge.getHead();
                    if((length+edge.getLength())<=e){
                        tempUS=edge.getScore()/edge.getLength();
                        if(tempUS>maxUS){
                            maxUS=tempUS;
                        }
                    }
                }
            }
        }
        return maxUS;
    }
}
