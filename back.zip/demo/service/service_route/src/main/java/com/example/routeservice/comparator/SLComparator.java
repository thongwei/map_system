package com.example.routeservice.comparator;

import com.example.routeservice.algorithm.NodeLabel;
import java.util.Comparator;

public class SLComparator implements Comparator<NodeLabel> {

    @Override
    public int compare(NodeLabel o1, NodeLabel o2) {
        int order=0;
        double gap = o1.getScore()/o1.getLength()-o2.getScore()/o2.getLength();
        if(gap>0){
            return 1;
        }
        else if(gap<0){
            return -1;
        }
        else{
            return 0;
        }
    }
}
