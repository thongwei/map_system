package com.example.routeservice.comparator;


import com.example.routeservice.algorithm.NodeLabel;

import java.util.Comparator;

public class DComparator implements Comparator<NodeLabel> {
    @Override
    public int compare(NodeLabel o1, NodeLabel o2) {//密度大的优先级高
        return o1.getDensity()>o2.getDensity() ? -1 : (o1.getDensity()<o2.getDensity() ? 1:0);
    }
}
