package com.example.routeservice.algorithm;


import com.example.routeservice.comparator.DistanceToComparator;
import com.example.routeservice.graph.Edge;
import com.example.routeservice.graph.Graph;

import java.util.*;

public class AlgorithmUtil {
    private static final double MAX_VALUE = 10000000;

    //获取路径的长度或分数
    public static double getPathInfo(Graph G, ArrayList<Integer> path, String weight){
        double result=0;
        if("length".equals(weight)){
            for(int i=0; i<path.size()-1; i++){
                int node1 = path.get(i);
                int node2 = path.get(i+1);
                Edge temp=null;
                for(Edge edge:G.getAdjList().get(node1)){
                    if(edge.getHead()==node2){
                        temp=edge;
                        break;
                    }
                }
                result+=temp.getLength();
            }
        }
        if("score".equals(weight)){
            for(int i=0; i<path.size()-1; i++){
                int node1 = path.get(i);
                int node2 = path.get(i+1);
                Edge temp=null;
                for(Edge edge:G.getAdjList().get(node1)){
                    if(edge.getHead()==node2){
                        temp=edge;
                        break;
                    }
                }
                result+=temp.getScore();
            }
        }
        return result;
    }

    //获取路径的POI
    public static ArrayList<Integer> getPOIs(Graph G, ArrayList<Integer> path, String queryCode, HashMap<Integer, HashMap<String,Object>> poi_dict){
        ArrayList<Integer> poi_ids = new ArrayList<>();
        for(int i=0; i<path.size()-1; i++){
            int node1 = path.get(i);
            int node2 = path.get(i+1);
            Edge temp=null;
            for(Edge edge:G.getAdjList().get(node1)){
                if(edge.getHead()==node2){
                    temp=edge;
                    break;
                }
            }
            HashSet<Integer> pois = temp.getPois();
            for(int poiId:pois){
                String targetCode = (String) poi_dict.get(poiId).get("typecode");
                if(G.computSimilarity(queryCode,targetCode)>0){
                    poi_ids.add(poiId);
                }
            }
        }
        return poi_ids;
    }

    //获取路径的边数
    public static int getEdgeNums(ArrayList<Integer> path){
        return path.size()-1;
    }

    public static ArrayList<Integer> getPath(Graph G,int start,int end,HashMap<Integer,Integer> paths){
        ArrayList<Integer> resultPath = new ArrayList<>();
        int node = end;
        while(node!=start){
            resultPath.add(node);
            node=paths.get(node);
        }
        resultPath.add(start);
        Collections.reverse(resultPath);
        return resultPath;
    }

    public static boolean judgeLoop(ArrayList<Integer> path){
        HashSet<Integer> nodeSet = new HashSet<>();
        int len1,len2;
        nodeSet.addAll(path);
        len1 = path.size();
        len2 = nodeSet.size();
        if(len2<len1){
            return true;
        }
        else{
            return false;
        }
    }

    //判断图中起点到终点是否连通
    public static boolean judgeConnect(Graph G, int source, int target){
        int cur_node,neiNode;
        HashMap<Integer,Boolean> visited = new HashMap<>();//访问标记数组
        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();
        for(Integer node:adjList.keySet()){
            visited.put(node,false);
        }
        Queue<Integer> Q = new LinkedList<>();
        if(!adjList.keySet().contains(source)){
            //System.out.println("起点不在");
            return false;
        }
        if(!adjList.keySet().contains(target)){
            //System.out.println("终点不在");
            return false;
        }
        //BFS
        visited.replace(source,true);
        Q.offer(source);
        while(!Q.isEmpty()){
            cur_node = Q.poll();
            for(Edge edge:adjList.get(cur_node)){
                neiNode = edge.getHead();
                if(visited.get(neiNode)==false){
                    visited.replace(neiNode,true);
                    Q.offer(neiNode);
                }
            }
        }
        if(visited.get(target)==true){
            return true;
        }else{
            return false;
        }
    }


    //单个终点的Dijkstra算法，返回一条路径
    public static ArrayList<Integer> singleDijkstra(Graph G, int source, int target){
        HashMap<Integer, Boolean> visited = new HashMap<>(); //记录结点是否被访问过
        HashMap<Integer,Double> dist = new HashMap<>(); //记录从起点到其他任意一点的路径长度
        HashMap<Integer,Integer> paths = new HashMap<>(); // 记录Path[i]表示从S到i的最短路径中，结点i之前的结点的编号,即对应点的前一个节点
        ArrayList<Integer> resultPath = new ArrayList<>(); //要返回的结果路径
        int minNode;
        double minDist;
        DistanceTo minDistanceTo;

        DistanceToComparator comparator = new DistanceToComparator();
        PriorityQueue<DistanceTo> Q = new PriorityQueue<DistanceTo>(comparator);//使用优先级队列查找当前距离最近的结点

        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();

        if(source==target){
            resultPath.add(source);
            return resultPath;
        }

        //初始化
        for(Integer node:adjList.keySet()){
            visited.put(node,false);
            if(node!=source){
                dist.put(node,MAX_VALUE);
            }
            else{
                dist.put(node,0.0);
            }
        }
        Q.add(new DistanceTo(source,0));
        while(Q.isEmpty()==false){
            minDistanceTo = Q.poll();
            minNode = minDistanceTo.getNode();
            minDist = minDistanceTo.getDistance();
            if(visited.get(minNode)==true){
                continue;
            }
            visited.replace(minNode,true);
            if(minNode==target){
                break;
            }

            for(Edge edge:adjList.get(minNode)){
                int nei=edge.getHead();
                if(minDist+edge.getLength()<dist.get(nei)){
                    dist.replace(nei,minDist+edge.getLength());
                    paths.put(nei,minNode);
                    Q.add(new DistanceTo(nei,dist.get(nei)));
                }
            }
        }

        //获取路径
        int node = target;
        while(node!=source){
            resultPath.add(node);
            node=paths.get(node);
        }
        resultPath.add(source);
        Collections.reverse(resultPath);
        return resultPath;
    }

    //多个终点的Dijkstra算法，返回到所有终点的距离,只返回距离
    public static HashMap<Integer,Double> multiDijkstra(Graph G, int source){
        HashMap<Integer, Boolean> visited = new HashMap<>(); //记录结点是否被访问过
        HashMap<Integer,Double> dist = new HashMap<>(); //记录从起点到其他任意一点的路径长度
        HashMap<Integer,Integer> paths = new HashMap<>(); // 记录Path[i]表示从S到i的最短路径中，结点i之前的结点的编号,即对应点的前一个节点
        int minNode;
        double minDist;
        DistanceTo minDistanceTo;

        DistanceToComparator comparator = new DistanceToComparator();
        PriorityQueue<DistanceTo> Q = new PriorityQueue<DistanceTo>(comparator);//使用优先级队列查找当前距离最近的结点

        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();

        //初始化
        for(Integer node:adjList.keySet()){
            visited.put(node,false);
            if(node!=source){
                dist.put(node,MAX_VALUE);
            }
            else{
                dist.put(node,0.0);
            }
        }
        Q.add(new DistanceTo(source,0));
        while(Q.isEmpty()==false){
            minDistanceTo = Q.poll();
            minNode = minDistanceTo.getNode();
            minDist = minDistanceTo.getDistance();
            if(visited.get(minNode)==true){
                continue;
            }
            visited.replace(minNode,true);

            for(Edge edge:adjList.get(minNode)){
                int nei=edge.getHead();
                if(minDist+edge.getLength()<dist.get(nei)){
                    dist.replace(nei,minDist+edge.getLength());
                    paths.put(nei,minNode);
                    Q.add(new DistanceTo(nei,dist.get(nei)));
                }
            }
        }

        return dist;
    }

    //多个终点的Dijkstra算法，返回到所有终点的距离，返回路径和距离
    public static HashMap<String, Object> multiDijkstra1(Graph G, int source){
        HashMap<String, Object> result = new HashMap<>();
        HashMap<Integer, Boolean> visited = new HashMap<>(); //记录结点是否被访问过
        HashMap<Integer,Double> dist = new HashMap<>(); //记录从起点到其他任意一点的路径长度
        HashMap<Integer,Integer> paths = new HashMap<>(); // 记录Path[i]表示从S到i的最短路径中，结点i之前的结点的编号,即对应点的前一个节点
        int minNode;
        double minDist;
        DistanceTo minDistanceTo;

        DistanceToComparator comparator = new DistanceToComparator();
        PriorityQueue<DistanceTo> Q = new PriorityQueue<DistanceTo>(comparator);//使用优先级队列查找当前距离最近的结点

        HashMap<Integer, ArrayList<Edge>> adjList = G.getAdjList();

        //初始化
        for(Integer node:adjList.keySet()){
            visited.put(node,false);
            if(node!=source){
                dist.put(node,MAX_VALUE);
            }
            else{
                dist.put(node,0.0);
            }
        }
        Q.add(new DistanceTo(source,0));
        while(Q.isEmpty()==false){
            minDistanceTo = Q.poll();
            minNode = minDistanceTo.getNode();
            minDist = minDistanceTo.getDistance();
            if(visited.get(minNode)==true){
                continue;
            }
            visited.replace(minNode,true);

            for(Edge edge:adjList.get(minNode)){
                int nei=edge.getHead();
                if(minDist+edge.getLength()<dist.get(nei)){
                    dist.replace(nei,minDist+edge.getLength());
                    paths.put(nei,minNode);
                    Q.add(new DistanceTo(nei,dist.get(nei)));
                }
            }
        }

        result.put("dist",dist);
        result.put("paths",paths);
        return result;
    }

    //给定经纬度，计算两点的欧氏距离
    public static double computeEucDist(double x1,double y1,double x2,double y2){
        return Math.sqrt(Math.pow(x1-x2,2)+Math.pow(y1-y2,2));
    }

    //给定经纬度，找与其最近的结点
    public static int getNearestNode(Graph G, double lng, double lat, HashMap<Integer, HashMap<String,Double>> node_dict){
        HashMap<String,Double> node_attr;
        int nearestNode=-1;
        double minDist = Double.MAX_VALUE;
        double x,y,dist;
        for(int node:node_dict.keySet()){
            node_attr = node_dict.get(node);
            x = node_attr.get("x");
            y = node_attr.get("y");
            dist = computeEucDist(lng,lat,x,y);
            if(dist<minDist){
                minDist = dist;
                nearestNode = node;
            }
        }
        return nearestNode;
    }

}
