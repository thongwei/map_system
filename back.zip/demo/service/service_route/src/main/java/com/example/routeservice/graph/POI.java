package com.example.routeservice.graph;

public class POI {
    private double x;
    private double y;
    private double rating;
    private String name;

    public POI(){}

    public POI(double x, double y, double rating, String name) {
        this.x = x;
        this.y = y;
        this.rating = rating;
        this.name = name;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
