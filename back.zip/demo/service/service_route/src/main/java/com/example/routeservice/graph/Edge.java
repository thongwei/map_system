package com.example.routeservice.graph;

import java.util.HashSet;

public class Edge {
    private int tail;
    private int head;
    private double length;
    private HashSet<Integer> pois;
    private double score;
    private double l_s;//长度除以分数
    private int visit = -1;//访问标记，getExactPOI方法会用到

    public Edge() {

    }

    public Edge(int tail, int head, double length, double score) {
        this.tail = tail;
        this.head = head;
        this.length = length;
        this.pois = new HashSet<Integer>();
        this.score = score;
    }

    public int getTail() {
        return tail;
    }

    public void setTail(int tail) {
        this.tail = tail;
    }

    public int getHead() {
        return head;
    }

    public void setHead(int head) {
        this.head = head;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public HashSet<Integer> getPois() {
        return pois;
    }

    public double getL_s() {
        return l_s;
    }

    public void setL_s(double l_s) {
        this.l_s = l_s;
    }

    public void setPois(HashSet<Integer> pois) {
        this.pois = pois;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }



    public void addPoi(int poi_id){
        this.pois.add(poi_id);
    }

    public int getVisit() {
        return visit;
    }

    public void setVisit(int visit) {
        this.visit = visit;
    }
}
