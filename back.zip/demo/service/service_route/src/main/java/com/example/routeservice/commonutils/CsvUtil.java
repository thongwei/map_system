package com.example.routeservice.commonutils;


import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class CsvUtil {
    public static List<RowElement> readCSV(String file_path){
        try{

//            File csv=new File(absolutePath);
//            InputStreamReader isr =new InputStreamReader(new FileInputStream(csv),"gbk");


            List<RowElement> rows = new ArrayList<RowElement>();
            File csv=new File(file_path);
            InputStreamReader isr =new InputStreamReader(new FileInputStream(csv),"utf-8");
            //BufferedReader br = new BufferedReader(new FileReader(csv));
            BufferedReader br = new BufferedReader(isr);
            String line=null;
            while((line=br.readLine())!=null){
                String[] cols= line.split(",");
                RowElement rowElement = new RowElement(cols);
                rows.add(rowElement);
            }
            isr.close();
            br.close();
            return rows;
        }catch (FileNotFoundException e) {
            System.out.println("文件没有发现");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("捕获BufferedReader对象关闭时的异常");
            e.printStackTrace();
        }
        return null;
    }

}
